import fs from 'node:fs';
import path from 'node:path';
import { validateE2eManifest } from './contract.mjs';

export default class PipelineReporter {
  constructor(options) { this.options = options; this.results = new Map(); this.errors = []; }
  onBegin(config, suite) {
    this.started = Date.now();
    this.cases = suite.allTests().map(test => {
      const project = test.parent.project().name;
      const [check, profile] = project.split('/');
      const annotations = test.annotations.filter(a => a.type === 'pipeline-id');
      if (annotations.length !== 1 || !annotations[0].description) throw new Error('Each test needs exactly one declaration-time pipeline-id annotation');
      const overrides = test.annotations.filter(a => a.type === 'pipeline-exact-id');
      if (overrides.length > 1 || (overrides.length && this.options.profileCounts[check] !== 1)) throw new Error('Exact IDs require a single profile');
      const testId = overrides[0]?.description || `${check}.${annotations[0].description}.${profile}`;
      const title = test.titlePath().slice(2);
      if (title.some(value => /[\n\r›>]/.test(value))) throw new Error('Test titles cannot contain test-list separators');
      const selector = `[${project}] › ${path.relative(config.rootDir, test.location.file)}:${test.location.line}:${test.location.column} › ${title.slice(1).join(' › ')}`;
      return { testId, name: title.join(' › '), labels: test.tags.map(t => t.replace(/^@/, '')).sort(), selector, internalId: test.id, expectedStatus: test.expectedStatus };
    });
    const manifest = validateE2eManifest({ format: 'pipeline-e2e-manifest-v1', tests: this.cases.map(({testId,name,labels}) => ({testId,name,labels})) });
    if (this.options.expectedIds) {
      const actual = manifest.tests.map(t => t.testId).sort();
      if (JSON.stringify(actual) !== JSON.stringify([...this.options.expectedIds].sort())) throw new Error('Playwright selection differs from the attested plan');
    }
    fs.writeFileSync(this.options.discoveryPath, JSON.stringify({manifest,cases:this.cases}));
  }
  onTestEnd(test, result) {
    const prior = this.results.get(test.id);
    const status = result.status === 'passed' && result.retry === 0 && test.expectedStatus === 'passed' && !prior ? 'passed' : result.status === 'skipped' ? 'skipped' : 'failed';
    this.results.set(test.id, {status, durationMs: (prior?.durationMs || 0) + Math.round(result.duration)});
  }
  onError(error) { this.errors.push(error.message || String(error)); console.error(error.message || String(error)); }
  onEnd(result) {
    fs.writeFileSync(this.options.resultPath, JSON.stringify({ status:result.status, durationMs:Date.now()-this.started || 0, errors:this.errors,
      tests:(this.cases || []).map(({testId,name,labels,internalId,expectedStatus}) => ({testId,name,labels,...(this.results.get(internalId) || {status:'skipped',durationMs:0}), ...(expectedStatus !== 'passed' ? {status:'failed'} : {})})) }));
  }
}
