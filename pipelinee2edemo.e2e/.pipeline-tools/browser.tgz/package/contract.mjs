// shared/standalone-e2e.ts
import { createHash } from "node:crypto";
var e2eManifestFormat = "pipeline-e2e-manifest-v1";
var e2ePackageFormat = "pipeline-e2e-package-v1";
var e2ePlanFormat = "pipeline-e2e-plan-v1";
var e2eReportFormat = "pipeline-e2e-v1";
var maximumTests = 5e3;
var maximumLabelsPerTest = 32;
var testIdPattern = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
var labelPattern = /^[a-z][a-z0-9_-]{0,63}$/;
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function exactFields(value, allowed, path) {
  const extras = Object.keys(value).filter((key) => !allowed.includes(key));
  if (extras.length > 0) {
    throw new Error(`${path} contains unsupported fields: ${extras.sort().join(", ")}`);
  }
}
function nonNegativeInteger(value, path) {
  if (!Number.isSafeInteger(value) || Number(value) < 0) {
    throw new Error(`${path} must be a non-negative integer`);
  }
  return Number(value);
}
function canonicalValue(value) {
  if (Array.isArray(value)) {
    return value.map(canonicalValue);
  }
  if (isRecord(value)) {
    return Object.fromEntries(
      Object.keys(value).sort().map((key) => [key, canonicalValue(value[key])])
    );
  }
  return value;
}
function canonicalE2eJson(value) {
  return JSON.stringify(canonicalValue(value));
}
function e2eDigest(value) {
  return createHash("sha256").update(canonicalE2eJson(value)).digest("hex");
}
function parseLabels(value, path) {
  if (!Array.isArray(value) || value.length < 1 || value.length > maximumLabelsPerTest) {
    throw new Error(
      `${path} must contain between 1 and ${maximumLabelsPerTest} labels`
    );
  }
  const labels = value.map((label, index) => {
    if (typeof label !== "string" || !labelPattern.test(label)) {
      throw new Error(`${path}[${index}] is invalid`);
    }
    return label;
  });
  if (new Set(labels).size !== labels.length) {
    throw new Error(`${path} must not contain duplicate labels`);
  }
  return labels.sort();
}
function parseManifestTest(value, path) {
  if (!isRecord(value)) {
    throw new Error(`${path} must be an object`);
  }
  exactFields(value, ["testId", "name", "labels"], path);
  if (typeof value.testId !== "string" || !testIdPattern.test(value.testId)) {
    throw new Error(`${path}.testId is invalid`);
  }
  if (typeof value.name !== "string" || value.name.trim() === "") {
    throw new Error(`${path}.name is required`);
  }
  return {
    labels: parseLabels(value.labels, `${path}.labels`),
    name: value.name.trim(),
    testId: value.testId
  };
}
function validateE2eManifest(input) {
  if (!isRecord(input)) {
    throw new Error("E2E manifest must be an object");
  }
  exactFields(input, ["format", "tests"], "E2E manifest");
  if (input.format !== e2eManifestFormat) {
    throw new Error(`E2E manifest format must be ${e2eManifestFormat}`);
  }
  if (!Array.isArray(input.tests) || input.tests.length < 1 || input.tests.length > maximumTests) {
    throw new Error(
      `E2E manifest must contain between 1 and ${maximumTests} tests`
    );
  }
  const tests = input.tests.map((test, index) => parseManifestTest(test, `E2E manifest.tests[${index}]`)).sort((left, right) => left.testId.localeCompare(right.testId));
  if (new Set(tests.map((test) => test.testId)).size !== tests.length) {
    throw new Error("E2E manifest contains duplicate test IDs");
  }
  return { format: e2eManifestFormat, tests };
}
function selectE2eTests(manifest, suiteName, suite) {
  const includeLabels = suite.includeLabels ?? [];
  if (suite.allTests === true && includeLabels.length > 0) {
    throw new Error(`E2E suite ${suiteName} cannot combine allTests and includeLabels`);
  }
  let selected;
  if (suite.allTests === true) {
    selected = manifest.tests;
  } else {
    if (includeLabels.length === 0) {
      throw new Error(
        `E2E suite ${suiteName} must set allTests or includeLabels`
      );
    }
    selected = manifest.tests.filter(
      (test) => suite.match === "all" ? includeLabels.every((label) => test.labels.includes(label)) : includeLabels.some((label) => test.labels.includes(label))
    );
  }
  if (selected.length === 0) {
    throw new Error(`E2E suite ${suiteName} selects zero tests`);
  }
  return selected;
}
function buildE2eExecutionPlan(tests, suiteName, suite) {
  const selected = [...tests].sort(
    (left, right) => left.testId.localeCompare(right.testId)
  );
  const serialLabels = new Set(suite.serialLabels ?? []);
  const serial = selected.filter(
    (test) => test.labels.some((label) => serialLabels.has(label))
  );
  const independent = selected.filter((test) => !serial.includes(test));
  const shards = [];
  if (serial.length > 0 && suite.maxParallelShards === 1) {
    shards.push({
      mode: "serial",
      shardId: "serial-0",
      testIds: selected.map((test) => test.testId)
    });
  } else {
    const parallelShardCount = Math.min(
      independent.length,
      suite.maxParallelShards - (serial.length > 0 ? 1 : 0)
    );
    if (parallelShardCount > 0) {
      const ordered = independent.map((test) => ({
        digest: e2eDigest(test.testId),
        testId: test.testId
      })).sort(
        (left, right) => left.digest.localeCompare(right.digest) || left.testId.localeCompare(right.testId)
      );
      const assignments = Array.from(
        { length: parallelShardCount },
        () => []
      );
      ordered.forEach((test, index) => {
        assignments[index % parallelShardCount].push(test.testId);
      });
      assignments.forEach((testIds, index) => {
        shards.push({
          mode: "parallel",
          shardId: `parallel-${index}`,
          testIds: testIds.sort()
        });
      });
    }
    if (serial.length > 0) {
      shards.push({
        mode: "serial",
        shardId: "serial-0",
        testIds: serial.map((test) => test.testId).sort()
      });
    }
  }
  if (shards.length === 0 || shards.length > suite.maxParallelShards) {
    throw new Error(`E2E suite ${suiteName} produced an invalid shard plan`);
  }
  return {
    format: e2ePlanFormat,
    maxParallelShards: suite.maxParallelShards,
    selectionDigest: e2eDigest(selected.map((test) => test.testId)),
    shards,
    suite: suiteName,
    targetDurationSeconds: suite.targetDurationSeconds
  };
}
function buildE2ePackageAttestation(rawManifest, suites) {
  const manifest = validateE2eManifest(rawManifest);
  const suiteEntries = Object.entries(suites).sort(
    ([left], [right]) => left.localeCompare(right)
  );
  if (suiteEntries.length === 0) {
    throw new Error("E2E package must declare at least one suite");
  }
  const attestedSuites = Object.fromEntries(
    suiteEntries.map(([suiteName, suite]) => {
      const selectedTests = selectE2eTests(manifest, suiteName, suite);
      const selectedTestIds = selectedTests.map((test) => test.testId);
      const plan = buildE2eExecutionPlan(selectedTests, suiteName, suite);
      return [suiteName, {
        maxParallelShards: plan.maxParallelShards,
        selectedTestIds,
        selectionDigest: e2eDigest(selectedTestIds),
        shards: plan.shards,
        targetDurationSeconds: plan.targetDurationSeconds
      }];
    })
  );
  return {
    format: e2ePackageFormat,
    manifest,
    manifestSha256: e2eDigest(manifest),
    suites: attestedSuites
  };
}
function validateE2ePackageAttestation(input) {
  if (!isRecord(input)) {
    throw new Error("E2E package attestation must be an object");
  }
  exactFields(
    input,
    ["format", "manifest", "manifestSha256", "suites"],
    "E2E package attestation"
  );
  if (input.format !== e2ePackageFormat) {
    throw new Error(`E2E package format must be ${e2ePackageFormat}`);
  }
  const manifest = validateE2eManifest(input.manifest);
  if (input.manifestSha256 !== e2eDigest(manifest)) {
    throw new Error("E2E package manifest digest does not match");
  }
  if (!isRecord(input.suites) || Object.keys(input.suites).length === 0) {
    throw new Error("E2E package suites are missing");
  }
  const suites = {};
  for (const [suiteName, rawSuite] of Object.entries(input.suites)) {
    if (!isRecord(rawSuite)) {
      throw new Error(`E2E package suite ${suiteName} must be an object`);
    }
    exactFields(
      rawSuite,
      [
        "maxParallelShards",
        "selectedTestIds",
        "selectionDigest",
        "shards",
        "targetDurationSeconds"
      ],
      `E2E package suite ${suiteName}`
    );
    if (!Array.isArray(rawSuite.selectedTestIds) || rawSuite.selectedTestIds.length === 0 || rawSuite.selectedTestIds.some(
      (testId) => typeof testId !== "string" || !testIdPattern.test(testId)
    )) {
      throw new Error(`E2E package suite ${suiteName} has invalid test IDs`);
    }
    const selectedTestIds = [...rawSuite.selectedTestIds].sort();
    const manifestIds = new Set(manifest.tests.map((test) => test.testId));
    if (new Set(selectedTestIds).size !== selectedTestIds.length || selectedTestIds.some((testId) => !manifestIds.has(testId)) || rawSuite.selectionDigest !== e2eDigest(selectedTestIds)) {
      throw new Error(`E2E package suite ${suiteName} digest does not match`);
    }
    const maxParallelShards = nonNegativeInteger(
      rawSuite.maxParallelShards,
      `E2E package suite ${suiteName}.maxParallelShards`
    );
    const targetDurationSeconds = nonNegativeInteger(
      rawSuite.targetDurationSeconds,
      `E2E package suite ${suiteName}.targetDurationSeconds`
    );
    if (maxParallelShards < 1 || maxParallelShards > 16 || targetDurationSeconds < 1 || !Array.isArray(rawSuite.shards) || rawSuite.shards.length < 1 || rawSuite.shards.length > maxParallelShards) {
      throw new Error(`E2E package suite ${suiteName} has an invalid shard plan`);
    }
    const shardIds = /* @__PURE__ */ new Set();
    const plannedTestIds = [];
    const shards = rawSuite.shards.map((rawShard, index) => {
      if (!isRecord(rawShard)) {
        throw new Error(`E2E package suite ${suiteName} shard ${index} is invalid`);
      }
      exactFields(
        rawShard,
        ["mode", "shardId", "testIds"],
        `E2E package suite ${suiteName} shard ${index}`
      );
      if (rawShard.mode !== "parallel" && rawShard.mode !== "serial" || typeof rawShard.shardId !== "string" || !/^(parallel|serial)-[0-9]+$/.test(rawShard.shardId) || !rawShard.shardId.startsWith(`${rawShard.mode}-`) || shardIds.has(rawShard.shardId) || !Array.isArray(rawShard.testIds) || rawShard.testIds.length < 1 || rawShard.testIds.some(
        (testId) => typeof testId !== "string" || !selectedTestIds.includes(testId)
      )) {
        throw new Error(`E2E package suite ${suiteName} shard ${index} is invalid`);
      }
      shardIds.add(rawShard.shardId);
      const testIds = [...rawShard.testIds].sort();
      plannedTestIds.push(...testIds);
      return {
        mode: rawShard.mode,
        shardId: rawShard.shardId,
        testIds
      };
    });
    if (canonicalE2eJson(plannedTestIds.sort()) !== canonicalE2eJson(selectedTestIds)) {
      throw new Error(`E2E package suite ${suiteName} shard tests do not match`);
    }
    suites[suiteName] = {
      maxParallelShards,
      selectedTestIds,
      selectionDigest: String(rawSuite.selectionDigest),
      shards,
      targetDurationSeconds
    };
  }
  return {
    format: e2ePackageFormat,
    manifest,
    manifestSha256: String(input.manifestSha256),
    suites
  };
}
function executionPlan(packageAttestation, suiteName) {
  const suite = packageAttestation.suites[suiteName];
  if (!suite) {
    throw new Error(`E2E package does not contain suite ${suiteName}`);
  }
  return {
    format: e2ePlanFormat,
    maxParallelShards: suite.maxParallelShards,
    selectionDigest: suite.selectionDigest,
    shards: suite.shards,
    suite: suiteName,
    targetDurationSeconds: suite.targetDurationSeconds
  };
}
function parseReportTest(value, path) {
  if (!isRecord(value)) {
    throw new Error(`${path} must be an object`);
  }
  exactFields(value, ["testId", "name", "labels", "status", "durationMs"], path);
  const manifestTest = parseManifestTest({
    labels: value.labels,
    name: value.name,
    testId: value.testId
  }, path);
  if (value.status !== "passed" && value.status !== "failed" && value.status !== "skipped") {
    throw new Error(`${path}.status is invalid`);
  }
  return {
    ...manifestTest,
    durationMs: nonNegativeInteger(value.durationMs, `${path}.durationMs`),
    status: value.status
  };
}
function validateE2eReport(input, packageAttestation, suiteName) {
  if (!isRecord(input)) {
    throw new Error("E2E report must be an object");
  }
  exactFields(
    input,
    ["format", "durationMs", "setup", "execution", "cleanup", "tests"],
    "E2E report"
  );
  if (input.format !== e2eReportFormat) {
    throw new Error(`E2E report format must be ${e2eReportFormat}`);
  }
  const suite = packageAttestation.suites[suiteName];
  if (!suite) {
    throw new Error(`E2E package does not contain suite ${suiteName}`);
  }
  if (!Array.isArray(input.tests)) {
    throw new Error("E2E report.tests must be an array");
  }
  const tests = input.tests.map((test, index) => parseReportTest(test, `E2E report.tests[${index}]`)).sort((left, right) => left.testId.localeCompare(right.testId));
  if (new Set(tests.map((test) => test.testId)).size !== tests.length) {
    throw new Error("E2E report contains duplicate test IDs");
  }
  if (tests.length !== suite.selectedTestIds.length || tests.some((test, index) => test.testId !== suite.selectedTestIds[index])) {
    throw new Error("E2E report test IDs do not match the selected suite");
  }
  const manifestById = new Map(
    packageAttestation.manifest.tests.map((test) => [test.testId, test])
  );
  for (const test of tests) {
    const expected = manifestById.get(test.testId);
    if (!expected || expected.name !== test.name || canonicalE2eJson(expected.labels) !== canonicalE2eJson(test.labels)) {
      throw new Error(`E2E report test ${test.testId} does not match its manifest`);
    }
  }
  if (!isRecord(input.setup)) {
    throw new Error("E2E report.setup must be an object");
  }
  exactFields(input.setup, ["status", "durationMs"], "E2E report.setup");
  if (input.setup.status !== "passed" && input.setup.status !== "failed") {
    throw new Error("E2E report.setup.status is invalid");
  }
  if (!isRecord(input.execution) || !Array.isArray(input.execution.shards)) {
    throw new Error("E2E report.execution must contain shards");
  }
  exactFields(
    input.execution,
    ["durationMs", "shards"],
    "E2E report.execution"
  );
  const expectedShards = new Map(
    suite.shards.map((shard) => [shard.shardId, shard])
  );
  const reportedShardIds = /* @__PURE__ */ new Set();
  const executionShards = input.execution.shards.map((rawShard, index) => {
    if (!isRecord(rawShard)) {
      throw new Error(`E2E report execution shard ${index} is invalid`);
    }
    exactFields(
      rawShard,
      ["mode", "shardId", "testIds", "durationMs", "status"],
      `E2E report execution shard ${index}`
    );
    const expected = typeof rawShard.shardId === "string" ? expectedShards.get(rawShard.shardId) : void 0;
    if (!expected || reportedShardIds.has(expected.shardId) || rawShard.mode !== expected.mode || canonicalE2eJson(rawShard.testIds) !== canonicalE2eJson(expected.testIds) || rawShard.status !== "passed" && rawShard.status !== "failed") {
      throw new Error(`E2E report execution shard ${index} does not match plan`);
    }
    const status = rawShard.status;
    reportedShardIds.add(expected.shardId);
    return {
      ...expected,
      durationMs: nonNegativeInteger(
        rawShard.durationMs,
        `E2E report execution shard ${index}.durationMs`
      ),
      status
    };
  });
  if (reportedShardIds.size !== expectedShards.size) {
    throw new Error("E2E report execution shards do not match plan");
  }
  if (!isRecord(input.cleanup)) {
    throw new Error("E2E report.cleanup must be an object");
  }
  exactFields(input.cleanup, ["status", "durationMs"], "E2E report.cleanup");
  if (input.cleanup.status !== "passed" && input.cleanup.status !== "failed") {
    throw new Error("E2E report.cleanup.status is invalid");
  }
  const report = {
    cleanup: {
      durationMs: nonNegativeInteger(
        input.cleanup.durationMs,
        "E2E report.cleanup.durationMs"
      ),
      status: input.cleanup.status
    },
    durationMs: nonNegativeInteger(input.durationMs, "E2E report.durationMs"),
    execution: {
      durationMs: nonNegativeInteger(
        input.execution.durationMs,
        "E2E report.execution.durationMs"
      ),
      shards: executionShards
    },
    format: e2eReportFormat,
    setup: {
      durationMs: nonNegativeInteger(
        input.setup.durationMs,
        "E2E report.setup.durationMs"
      ),
      status: input.setup.status
    },
    tests
  };
  const labelTotals = {};
  for (const test of tests) {
    for (const label of test.labels) {
      const total = labelTotals[label] ?? {
        durationMs: 0,
        failed: 0,
        passed: 0,
        skipped: 0
      };
      total.durationMs += test.durationMs;
      total[test.status] += 1;
      labelTotals[label] = total;
    }
  }
  const failed = tests.filter((test) => test.status === "failed").length;
  const passed = tests.filter((test) => test.status === "passed").length;
  const skipped = tests.filter((test) => test.status === "skipped").length;
  return {
    report,
    summary: {
      cleanupDurationMs: report.cleanup.durationMs,
      durationMs: report.durationMs,
      executionDurationMs: report.execution.durationMs,
      failed,
      labelTotals,
      passed,
      setupDurationMs: report.setup.durationMs,
      shardCount: report.execution.shards.length,
      skipped,
      status: failed === 0 && report.setup.status === "passed" && report.execution.shards.every((shard) => shard.status === "passed") && report.cleanup.status === "passed" ? "passed" : "failed",
      targetDurationSeconds: suite.targetDurationSeconds,
      testCount: tests.length,
      withinTargetDuration: report.durationMs <= suite.targetDurationSeconds * 1e3
    }
  };
}

// shared/browser-tests.ts
var browserComponentSchemaVersion = "2026-standalone-stage-v3";
var browserProfiles = {
  "desktop-chromium": { browserName: "chromium", viewport: { width: 1440, height: 900 } },
  "tablet-chromium": { browserName: "chromium", viewport: { width: 768, height: 1024 }, isMobile: true, hasTouch: true },
  "mobile-chromium": { browserName: "chromium", viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true },
  "mobile-webkit": { browserName: "webkit", viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true }
};
var browserRuntime = {
  format: "pipeline-browser-lock-v1",
  toolVersion: "1.0.0",
  playwrightVersion: "1.63.0",
  image: "mcr.microsoft.com/playwright@sha256:bc6ab0d6d44ff4826e4cb8c1e6d801e185bfc42bb0753f8e2a30efc70db054c7",
  platform: "linux/amd64",
  nodeVersion: "v24.20.0",
  artifactProtocol: 1,
  workers: 1,
  locale: "en-US",
  timezoneId: "UTC",
  colorScheme: "light",
  reducedMotion: "reduce"
};
function object(input, fields, name) {
  if (!input || typeof input !== "object" || Array.isArray(input)) throw new Error(`${name} must be an object`);
  const value = input;
  if (Object.keys(value).some((key) => !fields.includes(key))) throw new Error(`${name} contains unsupported fields`);
  return value;
}
function browserRelativePath(value) {
  if (typeof value !== "string" || !value || value.startsWith("/") || value.includes("\\") || value.split("/").some((part) => !part || part === "." || part === "..") || /[:\n\r]/.test(value)) throw new Error("Browser paths must be relative paths inside the component");
  return value;
}
function validateBrowserTests(input) {
  const root = object(input, ["checks", "configFile", "customProfiles"], "browserTests");
  if (!root.checks || typeof root.checks !== "object" || Array.isArray(root.checks)) throw new Error("browserTests.checks must be an object");
  const customProfiles = {};
  if (root.customProfiles !== void 0) {
    if (!root.customProfiles || typeof root.customProfiles !== "object" || Array.isArray(root.customProfiles) || Object.keys(root.customProfiles).length > 16) throw new Error("Invalid custom browser profiles");
    for (const [name, raw] of Object.entries(root.customProfiles)) {
      if (!/^[a-z][a-z0-9-]{0,31}$/.test(name) || name in browserProfiles) throw new Error("Invalid or reserved profile name");
      const profile = object(raw, ["browserName", "viewport", "deviceScaleFactor", "isMobile", "hasTouch"], "custom profile");
      const viewport = object(profile.viewport, ["width", "height"], "profile viewport");
      if (!["chromium", "webkit"].includes(String(profile.browserName)) || [viewport.width, viewport.height].some((value) => !Number.isSafeInteger(value) || Number(value) < 100 || Number(value) > 5e3)) throw new Error("Invalid browser or viewport");
      for (const key of ["isMobile", "hasTouch"]) if (profile[key] !== void 0 && typeof profile[key] !== "boolean") throw new Error("Invalid profile boolean");
      if (profile.deviceScaleFactor !== void 0 && (typeof profile.deviceScaleFactor !== "number" || profile.deviceScaleFactor < 1 || profile.deviceScaleFactor > 4)) throw new Error("Invalid device scale factor");
      customProfiles[name] = { ...profile, viewport: { ...viewport } };
    }
  }
  const checks = {};
  const names = Object.keys(root.checks);
  if (!names.length || names.length > 16) throw new Error("browserTests needs 1\u201316 checks");
  for (const [name, raw] of Object.entries(root.checks)) {
    if (!/^[a-z][a-z0-9-]{0,31}$/.test(name)) throw new Error("Invalid browser check name");
    const check = object(raw, ["phase", "testDir", "profiles", "target"], `browserTests.checks.${name}`);
    const target = object(check.target, ["kind", "input"], "browser target");
    if (check.phase !== "gate" || target.kind !== "deployment") throw new Error("Only gate/deployment browser checks are supported");
    if (typeof target.input !== "string" || !/^[a-zA-Z][a-zA-Z0-9_-]*\.[a-zA-Z][a-zA-Z0-9_-]*$/.test(target.input)) throw new Error("Browser target must reference a named deployment input");
    const profiles = check.profiles ?? ["desktop-chromium"];
    if (!Array.isArray(profiles) || !profiles.length || profiles.some((p) => typeof p !== "string" || !Object.hasOwn(browserProfiles, p) && !Object.hasOwn(customProfiles, p)) || new Set(profiles).size !== profiles.length) throw new Error("Unknown or duplicate browser profile");
    checks[name] = { phase: "gate", testDir: browserRelativePath(check.testDir), profiles: [...profiles], target: { kind: "deployment", input: target.input } };
  }
  return { ...Object.keys(customProfiles).length ? { customProfiles } : {}, ...root.configFile === void 0 ? {} : { configFile: browserRelativePath(root.configFile) }, checks };
}
function browserLock(config) {
  return { ...browserRuntime, profiles: [...new Set(Object.values(config.checks).flatMap((check) => check.profiles))].sort() };
}
function validateBrowserLock(lock, config) {
  if (canonicalE2eJson(lock) !== canonicalE2eJson(browserLock(config))) throw new Error("Unsupported or stale browser runtime lock; run pipeline-browser upgrade explicitly");
}
function browserBinding(config, lock) {
  validateBrowserLock(lock, config);
  return { format: "pipeline-browser-package-v1", configSha256: e2eDigest(config), runtimeSha256: e2eDigest(lock) };
}
export {
  browserBinding,
  browserComponentSchemaVersion,
  browserLock,
  browserProfiles,
  browserRelativePath,
  browserRuntime,
  buildE2eExecutionPlan,
  buildE2ePackageAttestation,
  canonicalE2eJson,
  e2eDigest,
  e2eManifestFormat,
  e2ePackageFormat,
  e2ePlanFormat,
  e2eReportFormat,
  executionPlan,
  selectE2eTests,
  validateBrowserLock,
  validateBrowserTests,
  validateE2eManifest,
  validateE2ePackageAttestation,
  validateE2eReport
};
