#!/usr/bin/env node
import fs from 'node:fs';
import { zipSync } from 'fflate';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { spawn, spawnSync } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { browserLock, browserProfiles, validateBrowserTests, validateBrowserLock, canonicalE2eJson, validateE2eManifest, buildE2ePackageAttestation, executionPlan, validateE2eReport } from './contract.mjs';
const here = path.dirname(fileURLToPath(import.meta.url));
const root = process.cwd();
const args = process.argv.slice(2);
const command = args.shift();
const flags = ['--native','--update-snapshots'];
const allowed = command === 'init' ? ['--input','--provider','--test-dir','--profiles','--environment'] : ['test','internal'].includes(command) ? ['--base-url','--suite',...flags] : [];
for(let i=0;i<args.length;i++) { if(!allowed.includes(args[i])) throw new Error(`Unsupported option ${args[i]}`);if(!flags.includes(args[i])) i++; }

function option(name, fallback) { const i=args.indexOf(name); if(i>=0 && (!args[i+1] || args[i+1].startsWith('--'))) throw new Error(`Missing ${name} value`); return i<0?fallback:args[i+1]; }
function read(file) { return JSON.parse(fs.readFileSync(path.resolve(root,file),'utf8')); }
function write(file,data) { fs.mkdirSync(path.dirname(file),{recursive:true}); fs.writeFileSync(file,`${JSON.stringify(data,null,2)}\n`); }
function within(file) { const resolved=path.resolve(root,file); if(!resolved.startsWith(root+path.sep)) throw new Error('Path escapes component'); return resolved; }
function configuration() {
  const component=read('pipeline-component.json');
  if(component.schemaVersion!=='2026-standalone-stage-v3') throw new Error('Managed browser checks require component schema v3');
  const browser=validateBrowserTests(component.browserTests), lock=read('pipeline-browser.lock.json'); validateBrowserLock(lock,browser);
  const gate=component.deployment?.gates?.e2e;
  if(!gate) throw new Error('E2E gate configuration missing');
  if(gate.artifactPath!=='.') throw new Error('Managed browser packages require artifactPath: . so configuration, dependencies, tests and baselines travel together');
  const pkg=read('package.json');
  if(pkg.workspaces || !fs.existsSync(path.join(root,'package-lock.json'))) throw new Error('Use a standalone npm component with its own package-lock.json; workspaces are not supported');
  for(const check of Object.values(browser.checks)) {
    const [binding,output]=check.target.input.split('.');
    if(!gate.inputs?.[binding]?.outputs?.includes(output)) throw new Error(`Undeclared deployment input: ${check.target.input}`);
    if(!fs.statSync(within(check.testDir)).isDirectory()) throw new Error(`Test directory missing: ${check.testDir}`);
  }
  for(const suite of Object.values(gate.suites)) if(suite.maxParallelShards!==1 || suite.command!=='npm run e2e') throw new Error('Managed suites require maxParallelShards: 1 and command npm run e2e');
  if(pkg.scripts?.e2e!=='pipeline-browser test' || pkg.scripts?.['e2e:manifest']!=='pipeline-browser manifest' || !component.build?.packageCommand?.includes('npm run e2e:manifest')) throw new Error('Run init to register managed execution and Package discovery scripts');
  return {component,browser,lock,gate};
}
function playwrightCli() {
  const require=createRequire(path.join(root,'package.json'));
  const file=require.resolve('@playwright/test/package.json');
  if(JSON.parse(fs.readFileSync(file,'utf8')).version!=='1.63.0') throw new Error('Install exact @playwright/test version 1.63.0');
  return path.join(path.dirname(file),'cli.js');
}
async function run(executable, arguments_, options={}) {
  return new Promise((resolve,reject)=>{
    const child=spawn(executable,arguments_,{cwd:root,stdio:'inherit',...options});
    child.once('error',reject);child.once('exit',(code,signal)=>{if(signal) console.error(`${executable} terminated by ${signal}`);resolve(code??1);});
  });
}
async function makeConfig(config,scratch,output,urls,expectedIds) {
  let fragment={};
  if(config.browser.configFile) {
    fragment=(await import(pathToFileURL(within(config.browser.configFile)).href)).default;
    if(!fragment || Object.keys(fragment).some(k=>!['use','expect','timeout','testMatch','testIgnore','globalSetup','globalTeardown'].includes(k))) throw new Error('Unsupported config field: selection, projects, reporters, retries, workers and output are platform-owned');
    if(fragment.use && Object.keys(fragment.use).some(k=>!['locale','timezoneId','colorScheme','reducedMotion','permissions','extraHTTPHeaders','ignoreHTTPSErrors','actionTimeout','navigationTimeout','trace','storageState'].includes(k))) throw new Error('Unsupported Playwright use override');
    if(fragment.use?.trace !== undefined && !['off','retain-on-failure'].includes(fragment.use.trace)) throw new Error('Trace capture must be off or retain-on-failure');
    if(fragment.use?.storageState !== undefined) fragment.use.storageState=within(fragment.use.storageState);
    for(const key of ['globalSetup','globalTeardown']) if(fragment[key]) fragment[key]=within(fragment[key]);
  }
  const profileCounts=Object.fromEntries(Object.entries(config.browser.checks).map(([name,check])=>[name,check.profiles.length]));
  const reporterOptions={discoveryPath:path.join(scratch,'discovery.json'),resultPath:path.join(scratch,'result.json'),profileCounts,...(expectedIds?{expectedIds}:{})};
  const value={...fragment,testIgnore:['**/._*',...[].concat(fragment.testIgnore??[])],testDir:root,workers:1,retries:0,forbidOnly:true,fullyParallel:false,preserveOutput:'always',globalTimeout:420000,updateSnapshots:args.includes('--update-snapshots')?'all':'none',
    snapshotPathTemplate:(process.env.PIPELINE_BROWSER_SNAPSHOTS_DIR??path.join(root,'__screenshots__'))+'/{projectName}/{testFilePath}/{arg}{ext}',outputDir:path.join(output,'results'),
    reporter:[['list'],[path.join(here,'reporter.mjs'),reporterOptions],['json',{outputFile:path.join(output,'playwright.json')}],['html',{outputFolder:path.join(output,'html'),open:'never'}]],
    use:{locale:config.lock.locale,timezoneId:config.lock.timezoneId,colorScheme:config.lock.colorScheme,reducedMotion:config.lock.reducedMotion,...fragment.use,trace:fragment.use?.trace??'retain-on-failure',screenshot:'only-on-failure',video:'off'},
    expect:{...fragment.expect,toHaveScreenshot:{...fragment.expect?.toHaveScreenshot,animations:'disabled',caret:'hide'}},
    projects:Object.entries(config.browser.checks).flatMap(([name,check])=>check.profiles.map(profile=>({name:`${name}/${profile}`,testDir:within(check.testDir),use:{...(config.browser.customProfiles?.[profile]??browserProfiles[profile]),baseURL:urls[name]}})))};
  const file=path.join(scratch,'playwright.config.cjs');const encoded=JSON.stringify(value,(_key,item)=>{if(typeof item==='function') throw new Error('Config functions are not supported; use hook modules');return item instanceof RegExp?{__pipelineRegExp:item.source,flags:item.flags}:item;});
  fs.writeFileSync(file,`module.exports = JSON.parse(${JSON.stringify(encoded)}, (_key, item) => item && typeof item === 'object' && typeof item.__pipelineRegExp === 'string' ? new RegExp(item.__pipelineRegExp,item.flags) : item);\n`);
  return {file,reporterOptions};
}
async function invoke(configFile,extra) { return run(process.execPath,[playwrightCli(),'test','--config',configFile,...extra]); }
async function discover(config,scratch,output,urls) {
  const generated=await makeConfig(config,scratch,output,urls);
  if(await invoke(generated.file,['--list'])!==0) {
    const details=fs.existsSync(generated.reporterOptions.resultPath)?read(generated.reporterOptions.resultPath):undefined;
    throw new Error('Playwright discovery failed'+(details?' ('+details.status+')':''));
  }
  return read(generated.reporterOptions.discoveryPath);
}
function resolveUrls(config) {
  const override=option('--base-url');
  if((process.env.PIPELINE_E2E_PLAN_PATH || process.env.CI) && (override || args.includes('--update-snapshots') || args.includes('--native'))) throw new Error('CI rejects URL overrides, native execution and baseline updates');
  const document=process.env.PIPELINE_INPUT_DOCUMENT_PATH?read(process.env.PIPELINE_INPUT_DOCUMENT_PATH):{};
  return Object.fromEntries(Object.entries(config.browser.checks).map(([name,check])=>{
    const [binding,output]=check.target.input.split('.'),value=override??document.inputs?.[binding]?.[output];
    if(!value) throw new Error(`Supply --base-url locally, or deployed input ${check.target.input} in CI`);
    const url=new URL(value);
    if(!['http:','https:'].includes(url.protocol) || url.username || url.password) throw new Error('Browser targets must be HTTP(S) URLs without credentials');
    return [name,url.href];
  }));
}
async function executeInside() {
  const config=configuration(),urls=resolveUrls(config);
  const output=process.env.PIPELINE_TEST_ARTIFACTS_DIR??path.join(root,'reports/browser');fs.mkdirSync(output,{recursive:true});
  const scratch=fs.mkdtempSync(path.join(root,'.pipeline-browser-'));
  try {
    const started=Date.now(), discovered=await discover(config,scratch,path.join(output,'discovery'),urls);
    const manifest=validateE2eManifest(read(config.gate.testManifestPath));
    if(canonicalE2eJson(discovered.manifest)!==canonicalE2eJson(manifest)) throw new Error('Discovery differs from packaged manifest');
    const attestation=buildE2ePackageAttestation(manifest,config.gate.suites);
    const plan=process.env.PIPELINE_E2E_PLAN_PATH?read(process.env.PIPELINE_E2E_PLAN_PATH):executionPlan(attestation,option('--suite',Object.keys(config.gate.suites)[0]));
    if(canonicalE2eJson(plan)!==canonicalE2eJson(executionPlan(attestation,plan.suite))) throw new Error('Plan differs from manifest/suite attestation');
    const setupDuration=Date.now()-started,executionStarted=Date.now(),tests=[],shards=[];
    let failed=false,setupFailed=false,cleanupFailed=false;
    for(const shard of plan.shards) {
      const shardStart=Date.now(),shardOutput=path.join(output,shard.shardId);fs.mkdirSync(shardOutput,{recursive:true});
      const generated=await makeConfig(config,scratch,shardOutput,urls,shard.testIds),list=path.join(scratch,'test-list.txt');
      fs.writeFileSync(list,shard.testIds.map(id=>discovered.cases.find(t=>t.testId===id).selector).join('\n')+'\n');
      fs.rmSync(generated.reporterOptions.resultPath,{force:true});
      let exit=1,result;
      try { exit=await invoke(generated.file,['--test-list',list]);result=read(generated.reporterOptions.resultPath); }
      catch(error) { write(path.join(shardOutput,'executor-error.json'),{message:error.message}); }
      const shardTests=shard.testIds.map(id=>result?.tests?.find(t=>t.testId===id)??{...manifest.tests.find(t=>t.testId===id),durationMs:0,status:'skipped'});
      const passed=exit===0 && result?.status==='passed' && shardTests.every(t=>t.status==='passed');
      cleanupFailed ||= !passed && shardTests.every(t=>t.status==='passed');
      failed ||= !passed;setupFailed ||= !passed && shardTests.every(t=>t.status==='skipped');
      tests.push(...shardTests);shards.push({...shard,durationMs:Date.now()-shardStart,status:passed?'passed':'failed'});
    }
    const executionDuration=Date.now()-executionStarted;
    const cleanupStarted=Date.now();
    // Downloadable HTML bundles preserve relative report assets. Traces remain separate ZIPs.
    for(const shard of shards) {
      const folder=path.join(output,shard.shardId);
      if(fs.existsSync(path.join(folder,'html'))) {
        try {
          const entries={};let bytes=0;
          const collect=directory=>{
            for(const entry of fs.readdirSync(directory,{withFileTypes:true})) {
              const file=path.join(directory,entry.name);
              if(entry.isDirectory()) collect(file);
              else if(entry.isFile()) {
                bytes+=fs.statSync(file).size;
                if(bytes>200*1024*1024 || Object.keys(entries).length>=2000) throw new Error('HTML report exceeds archive limits');
                entries[path.relative(folder,file).split(path.sep).join('/')]=fs.readFileSync(file);
              } else throw new Error('Unsupported HTML report entry');
            }
          };
          collect(path.join(folder,'html'));
          fs.writeFileSync(path.join(folder,'html-report.zip'),zipSync(entries,{level:6}));
        } catch(error) { failed=true;cleanupFailed=true;write(path.join(folder,'bundle-error.json'),{message:error.message}); }
      }
    }
    const cleanupDuration=Date.now()-cleanupStarted;
    const report={format:'pipeline-e2e-v1',durationMs:Date.now()-started,setup:{durationMs:setupDuration,status:setupFailed?'failed':'passed'},cleanup:{durationMs:cleanupDuration,status:cleanupFailed?'failed':'passed'},execution:{durationMs:executionDuration,shards},tests};
    validateE2eReport(report,attestation,plan.suite);
    const destination=process.env.PIPELINE_E2E_REPORT_PATH??within(config.gate.report.path);write(destination+'.tmp',report);fs.renameSync(destination+'.tmp',destination);
    const fonts=spawnSync('fc-list',[],{encoding:'utf8',timeout:5000});
    write(path.join(output,'runtime.json'),{...config.lock,node:process.version,architecture:process.arch,platform:process.platform,profiles:config.browser.customProfiles??browserProfiles,fontListSha256:fonts.status===0?createHash('sha256').update(fonts.stdout.split('\n').sort().join('\n')).digest('hex'):null});
    process.exitCode=failed?1:0;
  } finally { fs.rmSync(scratch,{recursive:true,force:true}); }
}
async function dockerTest() {
  const config=configuration();resolveUrls(config);
  if(args.includes('--native')) { await executeInside();return; }
  const scratch=fs.mkdtempSync(path.join(os.tmpdir(),'pipeline-browser-')),name=process.env.PIPELINE_BROWSER_CONTAINER_NAME??`pipeline-browser-${randomUUID()}`;
  const output=process.env.PIPELINE_TEST_ARTIFACTS_DIR??path.join(root,'reports/browser');fs.mkdirSync(output,{recursive:true});
  const environment={PIPELINE_TEST_ARTIFACTS_DIR:'/output',PIPELINE_E2E_REPORT_PATH:'/output/e2e-report.json',PIPELINE_BROWSER_SNAPSHOTS_DIR:'/baselines'};
  if(!/^pipeline-browser-[a-zA-Z0-9-]+$/.test(name)) throw new Error('Invalid container name');
  const baselines=path.join(root,'__screenshots__');fs.mkdirSync(baselines,{recursive:true});
  const mounts=['--mount',`type=bind,source=${root},target=/source,readonly`,'--mount',`type=bind,source=${output},target=/output`];
  for(const key of ['PIPELINE_E2E_PLAN_PATH','PIPELINE_INPUT_DOCUMENT_PATH']) if(process.env[key]) {fs.copyFileSync(process.env[key],path.join(scratch,key+'.json'));environment[key]='/inputs/'+key+'.json';}
  if(process.env.CI) environment.CI='1';
  for(const key of config.gate.requiredSecrets??[]) { if(/^AWS_|^PIPELINE_|^GITHUB_|^DOCKER_/.test(key)) throw new Error('Reserved environment variable cannot be forwarded');if(process.env[key]!==undefined) environment[key]=process.env[key]; }
  // Secret values are in a private env file, never Docker command arguments.
  fs.writeFileSync(path.join(scratch,'env'),Object.entries(environment).map(([key,value])=>{if(/[\r\n]/.test(value)) throw new Error('Multiline environment values are unsupported');return `${key}=${value}`;}).join('\n'),{mode:0o600});
  mounts.push('--mount',`type=bind,source=${scratch},target=/inputs,readonly`,'--mount',`type=bind,source=${baselines},target=/baselines${args.includes('--update-snapshots')?'':',readonly'}`);
  const dockerArgs=['run','--rm','--init','--name',name,'--platform',config.lock.platform,'--shm-size=512m','--add-host=host.docker.internal:host-gateway',...mounts,'--env-file',path.join(scratch,'env'),config.lock.image,'bash','-lc',
    'mkdir /work && cp -a /source/. /work/ && cd /work && rm -rf node_modules && npm ci --no-audit --no-fund && node node_modules/@pipeline-platform/browser/cli.mjs internal "$@"','pipeline-browser',...args];
  const stop=()=>{spawnSync('docker',['rm','-f',name],{stdio:'ignore',timeout:10000});};
  process.on('SIGTERM',stop);process.on('SIGINT',stop);
  try {
    const status=await run('docker',dockerArgs);
    const generated=path.join(output,'e2e-report.json');
    if(fs.existsSync(generated)) {const dest=process.env.PIPELINE_E2E_REPORT_PATH??within(config.gate.report.path);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.copyFileSync(generated,dest);}
    process.exitCode=status;
  } finally {stop();process.off('SIGTERM',stop);process.off('SIGINT',stop);fs.rmSync(scratch,{recursive:true,force:true});}
}
async function initialize() {
  const file=path.join(root,'pipeline-component.json'),pkg=read('package.json');
  const input=option('--input','deployment.appUrl'),[binding,output]=input.split('.');
  let component;
  if(fs.existsSync(file)) component=read(file);
  else {
    const provider=option('--provider');if(!provider) throw new Error('A new component requires --provider PROJECT-cdk and --input deployment.appUrl');
    component={schemaVersion:'2026-standalone-stage-v3',pluginVersion:'1.0.0',build:{command:'npm ci',packageCommand:'npm ci'},deployment:{gates:{e2e:{kind:'project-e2e',artifactPath:'.',testManifestPath:'test-manifest.json',inputs:{[binding]:{component:provider,outputs:[output]}},suites:{essential:{command:'npm run e2e',includeLabels:['essential'],match:'any',maxParallelShards:1,targetDurationSeconds:600}},report:{format:'pipeline-e2e-v1',path:'reports/e2e.json',requireLabelsOnEveryTest:true}}}},test:{command:'npm run e2e:doctor'}};
  }
  const browser=validateBrowserTests(component.browserTests??{checks:{browser:{phase:'gate',testDir:option('--test-dir','tests/e2e'),profiles:option('--profiles','desktop-chromium').split(','),target:{kind:'deployment',input}}}});
  const gate=component.deployment?.gates?.e2e;if(!gate) throw new Error('E2E gate registration missing');
  for(const check of Object.values(browser.checks)) {const [b,o]=check.target.input.split('.');if(!gate.inputs?.[b]?.outputs?.includes(o)) throw new Error('Input is not registered in the E2E gate');}
  if(fs.existsSync(path.join(root,'pipeline-browser.lock.json'))) validateBrowserLock(read('pipeline-browser.lock.json'),browser);
  component.schemaVersion='2026-standalone-stage-v3';component.browserTests=browser;
  gate.artifactPath='.';
  for(const suite of Object.values(gate.suites)) {suite.command='npm run e2e';suite.maxParallelShards=1;}
  pkg.scripts??={};if(pkg.scripts.e2e && pkg.scripts.e2e!=='pipeline-browser test') pkg.scripts['e2e:legacy']??=pkg.scripts.e2e;
  pkg.scripts.e2e='pipeline-browser test';pkg.scripts['e2e:manifest']='pipeline-browser manifest';pkg.scripts['e2e:doctor']='pipeline-browser doctor';
  if(!component.build.packageCommand.includes('npm run e2e:manifest')) component.build.packageCommand+=' && npm run e2e:manifest';
  pkg.devDependencies??={};pkg.devDependencies['@playwright/test']='1.63.0';
  write(file,component);write(path.join(root,'package.json'),pkg);write(path.join(root,'pipeline-browser.lock.json'),browserLock(browser));
  for(const check of Object.values(browser.checks)) {
    const dir=within(check.testDir);fs.mkdirSync(dir,{recursive:true});
    if(fs.readdirSync(dir).length===0) fs.writeFileSync(path.join(dir,'smoke.spec.ts'),`import { test, expect } from '@playwright/test';\ntest('page loads', { annotation: { type: 'pipeline-id', description: 'page-loads' }, tag: '@essential' }, async ({ page }) => {\n  await page.goto('/');\n  await expect(page.locator('body')).toBeVisible();\n});\n`);
  }
  const ignore=path.join(root,'.gitignore'),old=fs.existsSync(ignore)?fs.readFileSync(ignore,'utf8'):'';
  fs.writeFileSync(ignore,old+(old&&!old.endsWith('\n')?'\n':'')+['reports/','.pipeline-browser-*/'].filter(l=>!old.split('\n').includes(l)).map(l=>l+'\n').join(''));
  const rootConfigPath=path.resolve(root,'../project-config.json');
  if(fs.existsSync(rootConfigPath)) {
    const project=read(rootConfigPath),environments=project.environments??{};
    const selected=option('--environment',Object.keys(environments).find(name=>!environments[name].isProduction));
    if(selected && environments[selected]?.deployment?.subStages && !environments[selected].deployment.subStages.gates?.e2e) {
      if(environments[selected].isProduction) throw new Error('Initialize nonproduction first; production labels/policy require explicit project review');
      environments[selected].deployment.subStages.gates??={};
      environments[selected].deployment.subStages.gates.e2e={mode:'blocking',suite:'essential',timeoutSeconds:600,overridePolicy:'forbidden'};
      write(path.join(root,'project-config.browser-proposal.json'),project);
      console.log('Review project-config.browser-proposal.json before applying the proposed root gate registration.');
    }
  }
  console.log('Initialized. Run npm install, e2e:manifest and e2e:doctor. Existing harness preserved as e2e:legacy; migrate its cases before adoption. Root environment gate registration is still required for a new project.');
}
try {
  if(command==='init') await initialize();
  else if(command==='upgrade') {const component=read('pipeline-component.json');write(path.join(root,'pipeline-browser.lock.json'),browserLock(validateBrowserTests(component.browserTests)));console.log('Runtime lock updated explicitly; review screenshot baselines.');}
  else if(command==='test') await dockerTest();
  else if(command==='internal') {if(process.platform!=='linux'||process.arch!=='x64'||process.version!==configuration().lock.nodeVersion) throw new Error('Internal execution requires Linux x64');await executeInside();}
  else if(command==='manifest'||command==='doctor') {
    const config=configuration(),scratch=fs.mkdtempSync(path.join(root,'.pipeline-browser-'));
    try {const discovery=await discover(config,scratch,path.join(scratch,'reports'),{});buildE2ePackageAttestation(discovery.manifest,config.gate.suites);
      if(command==='manifest') write(within(config.gate.testManifestPath),discovery.manifest);
      else if(canonicalE2eJson(discovery.manifest)!==canonicalE2eJson(validateE2eManifest(read(config.gate.testManifestPath)))) throw new Error('Manifest is stale; run e2e:manifest');
      console.log(`${command}: ${discovery.manifest.tests.length} cases; runtime ${config.lock.playwrightVersion}`);
    } finally {fs.rmSync(scratch,{recursive:true,force:true});}
  } else throw new Error('Usage: pipeline-browser init --input deployment.appUrl | manifest | doctor | test --base-url URL [--suite NAME] | upgrade');
} catch(error) {console.error(error.message);process.exitCode=1;}
