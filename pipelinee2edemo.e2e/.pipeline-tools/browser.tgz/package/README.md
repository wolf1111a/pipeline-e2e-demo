# Pipeline Platform browser tooling

Managed Playwright Test CLI for standalone npm E2E components. Version 1.0.0 pins
Playwright 1.63.0 and a Linux amd64 Ubuntu browser image by digest. Docker runs
locally and inside the existing platform runner; no additional AWS service is needed.

Install the versioned tarball downloaded from your authorized platform project,
then run `npx --no-install pipeline-browser init --input deployment.appUrl`,
`npm install`, `npm run e2e:manifest` and `npm run e2e:doctor`.
A new component also supplies `--provider YOURPROJECT-cdk` to init.

Commands: `init`, `manifest`, `doctor`, `test`, `upgrade`.
Local tests accept `--base-url URL`, `--suite NAME`, `--update-snapshots` and
`--native` (functional debugging only). CI rejects URL/native/baseline overrides.
Use `http://host.docker.internal:PORT` for a local server bound to `0.0.0.0`.
Baseline review uses the pinned Docker runtime; it is never automatic in CI.

Tests declare a stable `pipeline-id` annotation and explicit tags such as
`@essential`. The tool generates the manifest, executes the exact selected set,
and emits the existing pipeline-e2e-v1 evidence plus reports/screenshots/traces.
Unexpected selected skips and expected-failure annotations fail the gate.
Do not put sensitive data into captured diagnostics; use `use.trace: 'off'` when needed.

Init preserves a previous harness as `e2e:legacy`. Migrate its assertions before
adoption; retaining its script does not execute it alongside the new suite.
Managed packaging requires artifactPath `.` and an independent npm lockfile.

Platform repository guides: `docs/pipeline-playwright-onboarding.md`,
`docs/pipeline-playwright-platform-design.md`, and
`docs/pipeline-playwright-implementation.md`. Deploy platform support before
committing v3 configuration to an application that uses the live pipeline.
